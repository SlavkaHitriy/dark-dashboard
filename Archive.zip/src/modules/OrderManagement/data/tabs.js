export const tabs = [
  {
    title: 'Products',
    value: 'products',
  },
  {
    title: 'Billings',
    value: 'billings',
  },
  {
    title: 'Inventory',
    value: 'inventory',
  },
  {
    title: 'History',
    value: 'history',
  },
]
